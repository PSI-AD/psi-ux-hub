import React, { useState, useCallback, useRef, useEffect, Component, ErrorInfo, ReactNode } from 'react';
import { 
  Mic, Sparkles, RefreshCw, Layout, Camera, Eye, EyeOff, Loader2, Wand2, ShieldCheck, History, ArrowRight, Code2, Settings, Home, Target, ChevronRight, BarChart3, AlertCircle, X, Globe, Briefcase, MapPin, Gauge, Package, Send, Activity
} from 'lucide-react';
import { useAuditManager } from './hooks/useAuditManager';
import { refineCodeWithVoice, refineBlockWithFeedback } from './services/geminiService';
import { Sidebar } from './components/Navigation/Sidebar';
import { ProjectSettings } from './components/Project/ProjectSettings';
import { RedesignBlocks } from './components/Auditor/RedesignBlocks';
import { CompetitorView } from './components/Benchmarking/CompetitorView';
import { ScoreCardGrid } from './components/Result/ScoreCardGrid';
import { CardDetail } from './components/Auditor/CardDetail';
import { Scorecard } from './components/Audit/Scorecard';
import { ComponentVault } from './components/Library/ComponentVault';
import { DevHandoff } from './components/Auditor/DevHandoff';
import { PresentationView } from './components/Report/PresentationView';
import { FirstMeetingDashboard } from './components/Project/FirstMeetingDashboard';
import { AppStatus, AuditFolder, RedesignBlock } from './types/index';

/**
 * Global Safety Boundary: Catches React #31 Errors and UI Invariants.
 */
class ErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError(_: Error) { return { hasError: true }; }
  componentDidCatch(error: Error, errorInfo: ErrorInfo) { 
    console.error("PSI Hub Critical Failure:", error, errorInfo); 
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="h-screen bg-[#020617] flex flex-col items-center justify-center p-12 text-center">
          <div className="w-20 h-20 rounded-3xl bg-rose-500/10 flex items-center justify-center mb-8 border border-rose-500/30">
            <AlertCircle className="text-rose-500" size={40} />
          </div>
          <h2 className="text-2xl font-black uppercase tracking-tighter mb-4 text-white">Project Data Collision</h2>
          <p className="text-slate-500 max-w-md mb-10 leading-relaxed">The Command Center encountered a structural data invariant (Error #31). Clearing the project cache will restore standard operating parameters.</p>
          <button 
            onClick={() => { localStorage.clear(); window.location.reload(); }}
            className="px-10 py-4 bg-psi-gold text-obsidian rounded-2xl font-black uppercase text-[10px] tracking-[0.4em] shadow-[0_20px_50px_rgba(212,175,55,0.2)] hover:scale-105 transition-all"
          >
            Reset Intelligence Core
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

const safeString = (val: any): string => {
  if (val === null || val === undefined) return '';
  if (typeof val === 'object') return JSON.stringify(val);
  return String(val);
};

function MainApp() {
  const { 
    projects, activeProject, activePage, switchProject, switchPage, status, startAudit, auditResult, setAuditResult, acceptOptimization,
    updateProjectSettings, toggleChecklistItem, handleLogoUpload, handleBrandAudit, runSiteScan, addProject, workspaceFolders, createWorkspaceFolder, deleteWorkspaceFolder, moveProjectToFolder
  } = useAuditManager();
  
  const [view, setView] = useState<'discovery' | 'audit' | 'settings' | 'market' | 'presentation' | 'vault'>('discovery');
  const [selectedHistoryFolder, setSelectedHistoryFolder] = useState<AuditFolder | null>(null);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [detailData, setDetailData] = useState<{ code: string; title: string } | null>(null);
  const [handoffBlock, setHandoffBlock] = useState<RedesignBlock | null>(null);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [isPredictionMode, setIsPredictionMode] = useState(false);
  const [showCurtain, setShowCurtain] = useState(false);
  const [showNewProjectModal, setShowNewProjectModal] = useState(false);
  const [babelAvailable, setBabelAvailable] = useState<boolean | null>(null);
  
  const [newProject, setNewProject] = useState({ name: '', url: '', industry: 'Real Estate', country: 'UAE' });
  const [regeneratingBlockId, setRegeneratingBlockId] = useState<string | null>(null);
  const [updatedBlockId, setUpdatedBlockId] = useState<string | null>(null);
  const [loadingStep, setLoadingStep] = useState(0);

  const auditSteps = [
    { primary: "Vision Engine Active", secondary: "Segmenting viewport into Design Units..." },
    { primary: "Aesthetic Analysis", secondary: "Applying Heuristic unit scoring..." },
    { primary: "Strategic Scoring", secondary: "Calculating visual weight and luxury patterns..." }
  ];

  useEffect(() => {
    const checkBabel = () => {
      if ((window as any).Babel) setBabelAvailable(true);
      else setTimeout(checkBabel, 500);
    };
    checkBabel();
    const timeout = setTimeout(() => { if (!(window as any).Babel) setBabelAvailable(false); }, 8000);
    return () => clearTimeout(timeout);
  }, []);

  useEffect(() => {
    if (activeProject?.brand?.dna && !activeProject.discoveryConfirmed && view !== 'discovery') {
      setView('discovery');
    }
  }, [activeProject?.brand?.dna, activeProject?.discoveryConfirmed, view]);

  useEffect(() => {
    let interval: any;
    if (status === AppStatus.AUDITING) {
      setLoadingStep(0);
      interval = setInterval(() => {
        setLoadingStep(prev => (prev < auditSteps.length - 1 ? prev + 1 : prev));
      }, 5000);
    }
    return () => clearInterval(interval);
  }, [status]);

  const togglePresentationMode = () => {
    setShowCurtain(true);
    setTimeout(() => {
      setIsPreviewMode(prev => !prev);
      if (!isPreviewMode) setView('presentation');
      else setView('audit');
      setTimeout(() => setShowCurtain(false), 500);
    }, 400);
  };

  const handleCapture = async () => {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: { cursor: 'always' } as any });
      const video = document.createElement('video'); video.srcObject = stream;
      video.onloadedmetadata = () => {
        video.play();
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth; canvas.height = video.videoHeight;
        canvas.getContext('2d')?.drawImage(video, 0, 0);
        setSelectedFile(canvas.toDataURL('image/jpeg'));
        stream.getTracks().forEach(t => t.stop());
      };
    } catch (err: any) { console.error("Capture failed", err); }
  };

  const handleAcceptAudit = () => {
    if (!auditResult) return;
    acceptOptimization(
      "Architectural Synthesis",
      "Heuristic-driven 100-point optimization.",
      selectedFile || "",
      auditResult.suggestedImage || "",
      auditResult.codeFix,
      auditResult.frictionPoints,
      [],
      { perf: auditResult.performanceScore, acc: auditResult.accessibilityScore, best: auditResult.bestPracticesScore, seo: auditResult.seoScore },
      auditResult.blocks || [],
      auditResult.rationale || []
    );
  };

  const handleRegenerateBlock = async (blockId: string, instruction?: string, mimic?: boolean) => {
    if (!auditResult || !activeProject) return;
    const block = auditResult.blocks?.find(b => b.id === blockId);
    if (!block) return;
    try {
      setRegeneratingBlockId(blockId);
      const refined = await refineCodeWithVoice(block.code, instruction || "Enhance layout efficiency.", mimic, activeProject.competitors);
      const updatedBlocks = auditResult.blocks?.map(b => b.id === blockId ? { ...b, code: refined.code } : b);
      setAuditResult({ ...auditResult, blocks: updatedBlocks });
      setUpdatedBlockId(blockId);
      setTimeout(() => setUpdatedBlockId(null), 3000);
    } catch (err) { console.error("Block regeneration failed", err); } finally { setRegeneratingBlockId(null); }
  };

  const handleDirectFeedback = async (blockId: string, feedback: { text: string; image?: string; voiceTranscript?: string }) => {
    if (!auditResult || !activeProject) return;
    const block = auditResult.blocks?.find(b => b.id === blockId);
    if (!block) return;
    try {
      setRegeneratingBlockId(blockId);
      const updatedBlock = await refineBlockWithFeedback(block, feedback, activeProject.brand);
      setAuditResult({ ...auditResult, blocks: auditResult.blocks?.map(b => b.id === blockId ? updatedBlock : b) });
      setUpdatedBlockId(blockId);
      setTimeout(() => setUpdatedBlockId(null), 3000);
    } catch (err) { console.error("Direct feedback refinement failed", err); } finally { setRegeneratingBlockId(null); }
  };

  const handleCreateProject = () => {
    if (newProject.name && newProject.url) {
      addProject(newProject.name, newProject.url, newProject.industry, newProject.country);
      setShowNewProjectModal(false);
      setNewProject({ name: '', url: '', industry: 'Real Estate', country: 'UAE' });
    }
  };

  if (babelAvailable === false) {
    return (
      <div className="h-screen bg-obsidian flex flex-col items-center justify-center p-12 text-center">
         <AlertCircle className="text-rose-500 mb-6" size={64} />
         <h2 className="text-2xl font-black uppercase tracking-tighter mb-4 text-white">Critical Load Failure</h2>
         <p className="text-slate-500 max-w-md mb-8">Babel Standalone was blocked by your browser security settings (CSP/CORS). Please ensure you are using the Nuclear Bypass policy.</p>
         <button onClick={() => window.location.reload()} className="px-8 py-3 bg-psi-gold text-obsidian rounded-xl font-black uppercase text-[10px] tracking-widest">Sync Systems</button>
      </div>
    );
  }

  const canRunAudit = activeProject?.brand?.logo && activeProject?.baseUrl;
  const currentBlocks = auditResult?.blocks || selectedHistoryFolder?.blocks || [];

  return (
    <div className={`flex h-screen bg-[#020617] text-white font-sans overflow-hidden transition-all duration-700 ${isPreviewMode ? 'p-0' : ''}`}>
      {!isPreviewMode && activeProject && activePage && (
        <Sidebar 
          projects={projects}
          activeProject={activeProject}
          activePage={activePage}
          workspaceFolders={workspaceFolders}
          onProjectSelect={switchProject}
          onPageSelect={(p) => { switchPage(p); setView('audit'); setSelectedHistoryFolder(null); }}
          onAddProject={() => setShowNewProjectModal(true)}
          onViewSettings={() => setView('settings')}
          onViewMarket={() => setView('market')}
          onViewLibrary={() => setView('vault')}
          createWorkspaceFolder={createWorkspaceFolder}
          deleteWorkspaceFolder={deleteWorkspaceFolder}
          moveProjectToFolder={moveProjectToFolder}
        />
      )}

      <main className="flex-1 flex flex-col overflow-hidden relative">
        {showCurtain && (
          <div className="fixed inset-0 z-[1000] bg-obsidian flex flex-col items-center justify-center animate-in fade-in duration-300">
            <div className="relative mb-6">
              <div className="w-24 h-24 border-2 border-psi-gold/20 border-t-psi-gold rounded-full animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center">
                <ShieldCheck className="text-psi-gold animate-pulse" size={32} />
              </div>
            </div>
            <h2 className="text-psi-gold font-luxury text-xl uppercase tracking-[0.4em] animate-pulse">Syncing Agency Soul</h2>
          </div>
        )}

        {view !== 'presentation' && activeProject && activePage && (
          <header className={`h-24 border-b border-white/10 bg-[#0a0a0b]/95 backdrop-blur-xl z-30 shrink-0 px-10 flex items-center justify-between transition-transform duration-500 ${isPreviewMode ? 'translate-y-[-100%]' : ''}`}>
            <div className="flex items-center gap-8">
              <div className="flex flex-col">
                <h1 className="text-[10px] font-black uppercase tracking-[0.4em] text-psi-gold">
                  {safeString(activeProject.name)}
                </h1>
                <p className="text-sm font-black text-white uppercase tracking-wider font-luxury flex items-center gap-2">
                  {safeString(activePage.name)} <ChevronRight size={14} className="text-slate-700" /> 
                  <span className="text-slate-400">
                    {safeString(view === 'discovery' ? 'Discovery Hub' : view === 'settings' ? 'Command Center' : view === 'market' ? 'Intelligence' : view === 'vault' ? 'Vault' : 'Iterative Audit')}
                  </span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4">
               {!isPreviewMode && (view === 'audit' || view === 'discovery') && auditResult && (
                 <div className="flex items-center gap-6 px-6 py-2 bg-white/5 border border-white/10 rounded-2xl">
                    <div className="flex flex-col items-center">
                      <span className="text-[7px] font-black text-slate-500 uppercase tracking-widest">Global Score</span>
                      <span className="text-xl font-black text-psi-gold">{safeString(auditResult.proposedHeuristics?.total || 0)}</span>
                    </div>
                    <div className="w-px h-8 bg-white/10" />
                    <ScoreCardGrid result={auditResult} />
                 </div>
               )}

               <div className="h-10 w-px bg-white/10 mx-4" />

               <div className="flex items-center gap-3">
                  {view === 'audit' && !isPreviewMode && (
                    <>
                      <button 
                        onClick={() => setIsPredictionMode(!isPredictionMode)}
                        className={`px-4 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 border ${isPredictionMode ? 'bg-psi-gold text-obsidian border-psi-gold' : 'bg-white/5 border border-white/10 text-slate-400 hover:text-white'}`}
                      >
                        <Activity size={16} /> Predict UX
                      </button>
                      <button onClick={handleCapture} className="px-6 py-3 bg-white/5 border border-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-white transition-all">
                        <Camera size={16} /> Capture
                      </button>
                      <button 
                        onClick={() => startAudit(selectedFile || undefined)}
                        disabled={status === AppStatus.AUDITING || !selectedFile || !canRunAudit}
                        className={`px-8 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 shadow-[0_0_20px_rgba(212,175,55,0.2)] transition-all ${canRunAudit ? 'bg-psi-gold hover:bg-[#F4CF47] text-slate-950' : 'bg-slate-800 text-slate-600 cursor-not-allowed opacity-50'}`}
                      >
                        {status === AppStatus.AUDITING ? <RefreshCw size={16} className="animate-spin" /> : <Sparkles size={16} />} Run 100pt Audit
                      </button>
                    </>
                  )}
                  <button 
                    onClick={togglePresentationMode} 
                    className={`p-3 rounded-xl border transition-all ${isPreviewMode ? 'bg-psi-gold border-psi-gold text-obsidian' : 'bg-white/5 border border-white/10 text-slate-400 hover:text-white'}`}
                    title="Client Presentation Mode"
                  >
                    {isPreviewMode ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
               </div>
            </div>
          </header>
        )}

        <div className="flex-1 overflow-y-auto custom-scrollbar bg-obsidian">
          {activeProject && (
            <>
              {view === 'discovery' ? (
                <FirstMeetingDashboard 
                  project={activeProject}
                  onConfirm={() => {
                    updateProjectSettings({ discoveryConfirmed: true });
                    setView('audit');
                  }}
                />
              ) : view === 'settings' ? (
                <ProjectSettings 
                  project={activeProject} 
                  onUpdate={updateProjectSettings} 
                  onLogoUpload={handleLogoUpload} 
                  onRunScan={runSiteScan} 
                  onRunBrandAudit={handleBrandAudit}
                  toggleChecklistItem={toggleChecklistItem}
                  isProcessing={status === AppStatus.AUDITING}
                />
              ) : view === 'market' ? (
                <CompetitorView 
                  project={activeProject} 
                  benchmarks={auditResult?.benchmarks} 
                />
              ) : view === 'vault' ? (
                <ComponentVault 
                  project={activeProject} 
                  onCopyCode={(code) => navigator.clipboard.writeText(code)}
                />
              ) : view === 'presentation' ? (
                <div className="animate-in fade-in zoom-in-95 duration-1000">
                   <PresentationView project={activeProject} onClose={togglePresentationMode} />
                </div>
              ) : (
                <div className="relative">
                  {status === AppStatus.AUDITING && (
                    <div className="absolute inset-0 z-50 bg-[#020617]/90 backdrop-blur-xl flex flex-col items-center justify-center p-12 text-center h-[calc(100vh-6rem)]">
                       <div className="relative mb-10">
                          <div className="w-32 h-32 border-2 border-white/10 border-t-psi-gold rounded-full animate-spin" />
                          <div className="absolute inset-0 flex items-center justify-center">
                            <Gauge className="text-psi-gold animate-pulse" size={40} />
                          </div>
                       </div>
                       <p className="text-xs font-black uppercase tracking-[0.5em] text-psi-gold animate-pulse">{safeString(auditSteps[loadingStep]?.primary || "Vision Engine Active")}</p>
                       <p className="text-[10px] text-slate-500 uppercase mt-4 tracking-widest">{safeString(auditSteps[loadingStep]?.secondary || "Segmenting viewport...")}</p>
                    </div>
                  )}

                  {auditResult && (
                    <div className="max-w-7xl mx-auto px-12 pt-12">
                       <Scorecard 
                        current={auditResult.currentHeuristics} 
                        proposed={auditResult.proposedHeuristics} 
                        rationale={auditResult.rationale}
                       />
                    </div>
                  )}

                  {currentBlocks.length > 0 ? (
                    <RedesignBlocks 
                      blocks={currentBlocks} 
                      competitors={activeProject.competitors}
                      onRegenerate={handleRegenerateBlock}
                      onAnnotate={(id, anno) => {
                        if (auditResult) {
                          setAuditResult({
                            ...auditResult,
                            blocks: auditResult.blocks?.map(b => b.id === id ? { ...b, annotations: [...b.annotations, anno] } : b)
                          });
                        }
                      }}
                      onOpenCode={(code, title) => setDetailData({ code, title })}
                      onDirectFeedback={handleDirectFeedback}
                      onOpenHandoff={(b) => setHandoffBlock(b)}
                      regeneratingBlockId={regeneratingBlockId}
                      updatedBlockId={updatedBlockId}
                      isPredictionMode={isPredictionMode}
                    />
                  ) : (
                    <div className="h-[50vh] flex flex-col items-center justify-center opacity-20 text-center px-12">
                       <Layout size={64} className="mb-6 text-slate-800" />
                       <h3 className="text-xl font-black uppercase tracking-[0.4em] text-slate-700">Audit Intelligence Offline</h3>
                       <p className="text-[10px] uppercase font-bold text-slate-800 mt-2">Capture a viewport to initialize the 100-point heuristic engine</p>
                    </div>
                  )}

                  {auditResult && (
                    <div className="fixed bottom-10 right-10 z-[100] animate-in slide-in-from-bottom duration-500">
                       <button onClick={handleAcceptAudit} className="px-12 py-5 bg-psi-gold text-obsidian font-black text-[10px] uppercase tracking-[0.4em] rounded-[2rem] shadow-[0_0_50px_rgba(212,175,55,0.3)] hover:scale-110 active:scale-95 transition-all">Commit Strategic Optimization</button>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        {detailData && activePage && (
          <CardDetail code={detailData.code} title={detailData.title} onClose={() => setDetailData(null)} pageName={activePage.name} />
        )}

        {handoffBlock && (
          <DevHandoff block={handoffBlock} onClose={() => setHandoffBlock(null)} />
        )}
      </main>

      {showNewProjectModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={() => setShowNewProjectModal(false)} />
           <div className="relative w-full max-w-xl bg-obsidian border border-white/10 rounded-[3rem] p-12 shadow-[0_50px_100px_rgba(0,0,0,0.8)] animate-in zoom-in-95 duration-500">
              <button onClick={() => setShowNewProjectModal(false)} className="absolute top-8 right-8 text-slate-500 hover:text-white"><X size={24}/></button>
              <h2 className="text-3xl font-black text-white uppercase tracking-tighter mb-2">New Strategic Mandate</h2>
              <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.4em] mb-10">Initial Project Configuration</p>
              
              <div className="space-y-8">
                <div className="space-y-4">
                  <label className="text-[10px] font-black uppercase tracking-widest text-psi-gold flex items-center gap-2"><Target size={14} /> Project Name</label>
                  <input type="text" value={newProject.name} onChange={(e) => setNewProject({...newProject, name: e.target.value})} placeholder="e.g., Al Reem Executive Towers" className="w-full bg-slate-900/50 border border-white/10 rounded-2xl p-5 text-sm text-white focus:border-psi-gold/50 outline-none transition-all" />
                </div>
                <div className="space-y-4">
                  <label className="text-[10px] font-black uppercase tracking-widest text-psi-gold flex items-center gap-2"><Globe size={14} /> Root Domain URL</label>
                  <input type="text" value={newProject.url} onChange={(e) => setNewProject({...newProject, url: e.target.value})} placeholder="https://example.com" className="w-full bg-slate-900/50 border border-white/10 rounded-2xl p-5 text-sm text-white focus:border-psi-gold/50 outline-none transition-all" />
                </div>
              </div>

              <button onClick={handleCreateProject} disabled={!newProject.name || !newProject.url} className="w-full mt-12 py-5 bg-psi-gold text-obsidian rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 shadow-[0_20px_40px_rgba(212,175,55,0.2)] hover:scale-105 active:scale-95 disabled:opacity-50 transition-all">Initialize Project Workspace <ChevronRight size={18} /></button>
           </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <MainApp />
    </ErrorBoundary>
  );
}