import React, { useState, useMemo } from 'react';
import { 
  Menu, Globe, CheckCircle2, Settings, Plus, FolderOpen, ChevronDown, ChevronUp, Layers, Layout, Briefcase, PlusCircle, Target, BarChart3, Package, ShieldAlert, FolderPlus, Folder, MoreVertical, Trash2, ArrowRight
} from 'lucide-react';
import { PSIProject, PSIPage, WorkspaceFolder } from '../../types/index';
import { checkProjectReadiness } from '../../services/projectService';

interface SidebarProps {
  projects: PSIProject[];
  activeProject: PSIProject;
  activePage: PSIPage;
  workspaceFolders: WorkspaceFolder[];
  onProjectSelect: (id: string) => void;
  onPageSelect: (page: PSIPage) => void;
  onAddProject: () => void;
  onViewSettings: () => void;
  onViewMarket: () => void;
  onViewLibrary: () => void;
  createWorkspaceFolder: (name: string) => void;
  deleteWorkspaceFolder: (id: string) => void;
  moveProjectToFolder: (projectId: string, folderId?: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  projects, activeProject, activePage, workspaceFolders, onProjectSelect, onPageSelect, onAddProject, onViewSettings, onViewMarket, onViewLibrary, createWorkspaceFolder, deleteWorkspaceFolder, moveProjectToFolder
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [expandedProjects, setExpandedProjects] = useState<Set<string>>(new Set([activeProject.id]));
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(workspaceFolders.map(f => f.id)));
  const [isCreatingFolder, setIsCreatingFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [activeMenuProjectId, setActiveMenuProjectId] = useState<string | null>(null);

  const toggleProject = (id: string) => {
    const next = new Set(expandedProjects);
    if (next.has(id)) next.delete(id); else next.add(id);
    setExpandedProjects(next);
  };

  const toggleFolder = (id: string) => {
    const next = new Set(expandedFolders);
    if (next.has(id)) next.delete(id); else next.add(id);
    setExpandedFolders(next);
  };

  const handleCreateFolder = (e: React.FormEvent) => {
    e.preventDefault();
    if (newFolderName.trim()) {
      createWorkspaceFolder(newFolderName.trim());
      setNewFolderName('');
      setIsCreatingFolder(false);
    }
  };

  const groupedProjects = useMemo(() => {
    const uncategorized: PSIProject[] = [];
    const inFolders: Record<string, PSIProject[]> = {};

    projects.forEach(p => {
      if (p.folderId && workspaceFolders.some(f => f.id === p.folderId)) {
        if (!inFolders[p.folderId]) inFolders[p.folderId] = [];
        inFolders[p.folderId].push(p);
      } else {
        uncategorized.push(p);
      }
    });

    return { uncategorized, inFolders };
  }, [projects, workspaceFolders]);

  const ProjectItem = ({ project }: { project: PSIProject }) => {
    const readiness = checkProjectReadiness(project);
    const isExpanded = expandedProjects.has(project.id);
    const isActive = activeProject.id === project.id;

    return (
      <div className="space-y-1">
        <div 
          onClick={() => { onProjectSelect(project.id); toggleProject(project.id); }}
          className={`group/project flex items-center justify-between p-3 cursor-pointer rounded-xl transition-all relative ${
            isActive ? 'bg-white/5 border border-white/10' : 'hover:bg-white/5'
          }`}
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-slate-900 flex items-center justify-center border border-white/10 relative shrink-0">
               {project.brand.logo ? <img src={project.brand.logo} className="w-6 h-6 object-contain" /> : <Globe size={14} className="text-slate-500" />}
               <div className={`absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full border-2 border-obsidian ${readiness.isReady ? 'bg-psi-gold status-pulse' : 'bg-rose-500'}`} />
            </div>
            {!isCollapsed && (
              <div className="flex flex-col min-w-0">
                <span className="text-[10px] font-black text-white uppercase tracking-wider truncate">{String(project.name || 'UNNAMED')}</span>
                <span className="text-[8px] text-slate-500 font-mono truncate">{String(project.baseUrl || 'no-url')}</span>
              </div>
            )}
          </div>
          
          {!isCollapsed && (
            <div className="flex items-center gap-1">
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setActiveMenuProjectId(activeMenuProjectId === project.id ? null : project.id);
                }}
                className="p-1 text-slate-600 hover:text-white opacity-0 group-hover/project:opacity-100 transition-opacity"
              >
                <MoreVertical size={14} />
              </button>
              {isExpanded ? <ChevronUp size={14} className="text-slate-600" /> : <ChevronDown size={14} className="text-slate-600" />}
            </div>
          )}

          {/* Project Management Menu */}
          {activeMenuProjectId === project.id && (
            <div 
              className="absolute left-full ml-2 top-0 w-48 bg-slate-900 border border-white/10 rounded-xl shadow-2xl z-[60] p-2 animate-in fade-in slide-in-from-left-2 duration-200"
              onMouseLeave={() => setActiveMenuProjectId(null)}
            >
              <p className="px-3 py-2 text-[8px] font-black text-slate-500 uppercase tracking-widest border-b border-white/5 mb-1">Group to Folder</p>
              <button 
                onClick={(e) => { e.stopPropagation(); moveProjectToFolder(project.id, undefined); setActiveMenuProjectId(null); }}
                className="w-full flex items-center gap-2 p-2 rounded-lg text-[9px] font-bold text-slate-300 hover:bg-white/5 hover:text-white transition-all"
              >
                <Layers size={12} /> Uncategorized
              </button>
              {workspaceFolders.map(f => (
                <button 
                  key={f.id}
                  onClick={(e) => { e.stopPropagation(); moveProjectToFolder(project.id, f.id); setActiveMenuProjectId(null); }}
                  className={`w-full flex items-center gap-2 p-2 rounded-lg text-[9px] font-bold transition-all ${project.folderId === f.id ? 'text-psi-gold bg-psi-gold/5' : 'text-slate-300 hover:bg-white/5 hover:text-white'}`}
                >
                  <Folder size={12} /> {String(f.name || 'Untitled')}
                </button>
              ))}
            </div>
          )}
        </div>

        {!isCollapsed && isExpanded && (
          <div className="ml-6 space-y-1 mt-2 animate-in slide-in-from-top-2 duration-300">
            {!readiness.isReady && (
              <div className="px-3 py-2 bg-rose-500/10 border border-rose-500/20 rounded-lg mb-2">
                 <p className="text-[7px] font-black text-rose-500 uppercase tracking-widest flex items-center gap-1">
                   <ShieldAlert size={10} /> Intelligence Gap
                 </p>
              </div>
            )}
            <button
                onClick={onViewMarket}
                className="w-full flex items-center gap-3 p-2.5 rounded-lg text-left transition-all text-slate-500 hover:text-psi-gold"
              >
                <BarChart3 size={12} />
                <span className="text-[10px] font-bold uppercase tracking-tight">Market Comparison</span>
              </button>
            <button
                onClick={onViewLibrary}
                className="w-full flex items-center gap-3 p-2.5 rounded-lg text-left transition-all text-slate-500 hover:text-psi-gold"
              >
                <Package size={12} />
                <span className="text-[10px] font-bold uppercase tracking-tight">Component Vault</span>
              </button>
            {project.pages.map(page => (
              <button
                key={page.id}
                onClick={() => onPageSelect(page)}
                className={`w-full flex items-center gap-3 p-2.5 rounded-lg text-left transition-all ${
                  activePage.id === page.id ? 'text-psi-gold bg-psi-gold/5' : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                <CheckCircle2 size={12} className={page.status === 'improved' ? 'text-emerald-500' : 'text-slate-800'} />
                <span className="text-[10px] font-bold uppercase tracking-tight truncate">{String(page.name || 'Untitled Page')}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <aside 
      className={`relative h-screen bg-[#050505]/95 border-r border-white/10 transition-all duration-500 ease-in-out flex flex-col z-50 shrink-0 ${
        isCollapsed ? 'w-20' : 'w-80'
      }`}
    >
      <div className="flex flex-col border-b border-white/10 p-6">
        <div className="flex items-center justify-between mb-8">
          <div className={`flex items-center gap-3 ${isCollapsed ? 'hidden' : ''}`}>
             <div className="w-8 h-8 bg-psi-gold rounded-lg flex items-center justify-center text-obsidian">
                <Target size={18} />
             </div>
             <h1 className="text-psi-gold font-black text-xs tracking-widest uppercase">Agency Hub</h1>
          </div>
          <button onClick={() => setIsCollapsed(!isCollapsed)} className="p-2 text-slate-400 hover:text-white transition-colors">
            <Menu size={20} />
          </button>
        </div>

        {!isCollapsed && (
          <div className="flex flex-col gap-2">
            <button 
              onClick={onAddProject}
              className="w-full flex items-center justify-center gap-2 py-3 bg-psi-gold text-obsidian rounded-xl text-[10px] font-black uppercase tracking-[0.2em] shadow-lg hover:scale-[1.02] transition-all"
            >
              <PlusCircle size={16} /> New Project
            </button>
            <button 
              onClick={() => setIsCreatingFolder(true)}
              className="w-full flex items-center justify-center gap-2 py-3 bg-white/5 border border-white/10 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 hover:bg-white/10 transition-all"
            >
              <FolderPlus size={16} /> New Folder
            </button>
          </div>
        )}
      </div>

      <nav className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-6">
        {/* Create Folder UI */}
        {isCreatingFolder && !isCollapsed && (
          <div className="p-4 bg-slate-900/50 border border-psi-gold/30 rounded-2xl animate-in zoom-in-95 duration-200">
            <form onSubmit={handleCreateFolder} className="space-y-4">
              <div className="flex items-center gap-2 text-psi-gold">
                <FolderPlus size={14} />
                <span className="text-[10px] font-black uppercase tracking-widest">Create Group</span>
              </div>
              <input 
                autoFocus
                type="text"
                placeholder="Folder name..."
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                className="w-full bg-obsidian border border-white/10 rounded-lg p-2 text-xs text-white outline-none focus:border-psi-gold/50"
              />
              <div className="flex gap-2">
                <button type="button" onClick={() => setIsCreatingFolder(false)} className="flex-1 py-2 text-[8px] font-black uppercase tracking-widest text-slate-500 hover:text-white">Cancel</button>
                <button type="submit" className="flex-1 py-2 bg-psi-gold text-obsidian rounded-lg text-[8px] font-black uppercase tracking-widest">Create</button>
              </div>
            </form>
          </div>
        )}

        {/* Workspace Folders */}
        {workspaceFolders.map(folder => {
          const folderProjects = groupedProjects.inFolders[folder.id] || [];
          const isExpanded = expandedFolders.has(folder.id);

          return (
            <div key={folder.id} className="space-y-2">
              <div 
                className="group flex items-center justify-between px-2 py-1 cursor-pointer"
                onClick={() => toggleFolder(folder.id)}
              >
                <div className="flex items-center gap-2">
                  <div className={`transition-transform duration-300 ${isExpanded ? 'rotate-0' : '-rotate-90'}`}>
                    <ChevronDown size={14} className="text-slate-600" />
                  </div>
                  <Folder size={14} className={folderProjects.length > 0 ? 'text-psi-gold' : 'text-slate-700'} />
                  {!isCollapsed && (
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest truncate max-w-[140px] group-hover:text-white transition-colors">{String(folder.name || 'Untitled')}</span>
                  )}
                </div>
                {!isCollapsed && (
                  <div className="flex items-center gap-2">
                    <span className="text-[8px] font-black text-slate-700 group-hover:text-slate-500">{folderProjects.length}</span>
                    <button 
                      onClick={(e) => { e.stopPropagation(); deleteWorkspaceFolder(folder.id); }}
                      className="p-1 text-slate-800 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                )}
              </div>
              
              {!isCollapsed && isExpanded && (
                <div className="ml-4 space-y-2 border-l border-white/5 pl-2 animate-in slide-in-from-left-2 duration-300">
                  {folderProjects.length > 0 ? (
                    folderProjects.map(project => (
                      <ProjectItem key={project.id} project={project} />
                    ))
                  ) : (
                    <p className="py-4 text-[8px] text-slate-700 uppercase font-black tracking-widest text-center italic">Empty Group</p>
                  )}
                </div>
              )}
            </div>
          );
        })}

        {/* Uncategorized Projects */}
        <div className="space-y-2">
          {!isCollapsed && (
            <div className="px-2 py-1 flex items-center gap-2 opacity-30">
              <Layers size={14} />
              <span className="text-[10px] font-black uppercase tracking-widest">Uncategorized</span>
            </div>
          )}
          {groupedProjects.uncategorized.map(project => (
            <ProjectItem key={project.id} project={project} />
          ))}
        </div>
      </nav>

      <div className="p-6 border-t border-white/10 flex flex-col gap-2">
        <button 
          onClick={onViewSettings}
          className={`w-full flex items-center p-3 rounded-xl text-slate-500 hover:text-white transition-all ${isCollapsed ? 'justify-center' : 'gap-4 bg-white/5'}`}
        >
          <Settings size={20} />
          {!isCollapsed && <span className="text-[10px] font-black uppercase tracking-widest">Command Center</span>}
        </button>
      </div>
    </aside>
  );
};