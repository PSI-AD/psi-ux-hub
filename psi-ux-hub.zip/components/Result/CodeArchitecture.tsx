
import React, { useEffect } from 'react';
import { Copy, CheckCircle2, Terminal, Cpu, Braces, Code2, ChevronRight, FlaskConical } from 'lucide-react';

interface CodeArchitectureProps {
  code: string;
  onCopy: () => void;
  copied: boolean;
  onOpenSandbox: () => void;
}

export const CodeArchitecture: React.FC<CodeArchitectureProps> = ({ code, onCopy, copied, onOpenSandbox }) => {
  useEffect(() => {
    // @ts-ignore
    if (window.Prism) {
      // @ts-ignore
      window.Prism.highlightAll();
    }
  }, [code]);

  return (
    <div className="flex-1 flex flex-col overflow-hidden animate-fade-in bg-[#0d1117] border-l border-slate-800">
      {/* Code Header Bar */}
      <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/40 backdrop-blur-md sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-psi-gold/10 rounded-lg text-psi-gold border border-psi-gold/20 shadow-inner">
            <Cpu size={18} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-widest text-white">Production Architecture</span>
              <span className="px-1.5 py-0.5 bg-blue-500/10 text-blue-400 text-[8px] font-bold rounded border border-blue-500/20">TSX</span>
            </div>
            <p className="text-[9px] text-slate-500 font-bold uppercase tracking-tight mt-0.5 flex items-center gap-1">
              Optimized for psinv.net <ChevronRight size={10} /> v4.0.0
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={onOpenSandbox}
            className="flex items-center gap-2 px-3 py-2 rounded-xl text-[10px] font-black uppercase transition-all bg-psi-gold/10 text-psi-gold border border-psi-gold/20 hover:bg-psi-gold/20 active:scale-95"
          >
            <FlaskConical size={12} />
            Try in Sandbox
          </button>
          <button 
            onClick={onCopy} 
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all shadow-2xl active:scale-95 border ${
              copied 
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' 
                : 'bg-slate-800 text-white border-slate-700 hover:bg-slate-700 hover:border-slate-600'
            }`}
          >
            {copied ? <CheckCircle2 size={12} className="animate-bounce" /> : <Copy size={12} />} 
            {copied ? 'Success' : 'Copy Fix'}
          </button>
        </div>
      </div>

      {/* Code Body */}
      <div className="flex-1 overflow-auto custom-scrollbar relative group/code">
        {/* Background Decorative Braces */}
        <div className="absolute top-10 right-10 opacity-[0.03] pointer-events-none group-hover/code:opacity-[0.07] transition-opacity duration-1000">
          <Code2 size={240} className="text-psi-gold" />
        </div>
        
        <div className="relative">
          <pre className="p-8 text-[13px] font-mono leading-relaxed selection:bg-psi-gold/20">
            <code className="language-tsx line-numbers">{code}</code>
          </pre>
        </div>
      </div>

      {/* Footer Info */}
      <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between text-[9px] text-slate-500 font-bold uppercase tracking-widest">
        <div className="flex items-center gap-5">
          <div className="flex items-center gap-1.5 hover:text-slate-300 transition-colors cursor-default">
            <Terminal size={12} className="text-emerald-500" />
            <span>Compiled Successfully</span>
          </div>
          <div className="flex items-center gap-1.5 hover:text-slate-300 transition-colors cursor-default border-l border-slate-800 pl-5">
            <Braces size={12} className="text-psi-gold" />
            <span>Tailwind CSS v4.0 Engine</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span>Deployable Module</span>
        </div>
      </div>
    </div>
  );
};
