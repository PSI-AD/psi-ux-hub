import React from 'react';

interface ScoreCircleProps {
  score: number;
  label: string;
}

export const ScoreCircle: React.FC<ScoreCircleProps> = ({ score, label }) => {
  const color = score > 89 ? 'text-emerald-400' : score > 49 ? 'text-amber-400' : 'text-rose-400';
  const strokeColor = score > 89 ? '#34d399' : score > 49 ? '#fbbf24' : '#fb7185';
  const radius = 30;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="flex flex-col items-center gap-1">
      <div className="relative w-16 h-16 flex items-center justify-center">
        <svg 
          className="w-full h-full -rotate-90 score-svg" 
          viewBox="0 0 64 64"
          style={{ 
            filter: 'drop-shadow(0 0 8px rgba(197, 160, 89, 0.15))',
          }}
        >
          <circle cx="32" cy="32" r={radius} fill="transparent" stroke="#1e293b" strokeWidth="6" />
          <circle 
            cx="32" cy="32" r={radius} fill="transparent" stroke={strokeColor} strokeWidth="6" 
            strokeDasharray={circumference} strokeDashoffset={offset} strokeLinecap="round"
            className="transition-all duration-1000 ease-out"
          />
        </svg>
        <span className={`absolute text-sm font-black tracking-tighter ${color}`}>{score}</span>
      </div>
      <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">{label}</span>
    </div>
  );
};