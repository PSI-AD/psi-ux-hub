import React, { useState, useEffect } from 'react';
import { Mic, Square, Loader2, Volume2 } from 'lucide-react';
import { processVoiceInput } from '../../services/geminiService';

interface VoiceInputProps {
  onTranscription: (text: string) => void;
  isProcessing?: boolean;
}

export const VoiceInput: React.FC<VoiceInputProps> = ({ onTranscription, isProcessing }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const startRecording = async () => {
    try {
      setIsRecording(true);
      setError(null);
      const text = await processVoiceInput();
      onTranscription(text);
      setIsRecording(false);
    } catch (err: any) {
      console.error("Voice capture failed:", err);
      setError(err === "Speech Recognition not supported." ? err : "Mic access failed.");
      setIsRecording(false);
    }
  };

  return (
    <div className="flex flex-col items-center gap-2">
      <button
        onClick={startRecording}
        disabled={isRecording || isProcessing}
        className={`relative p-4 rounded-2xl transition-all duration-500 flex items-center justify-center group ${
          isRecording 
            ? 'bg-rose-600 shadow-[0_0_30px_rgba(225,29,72,0.4)] animate-pulse' 
            : 'bg-white/5 border border-white/10 hover:border-psi-gold/50 text-slate-400 hover:text-psi-gold'
        }`}
        title={isRecording ? "Listening..." : "Record Voice Note"}
      >
        {isRecording ? (
          <Square size={20} className="text-white fill-white" />
        ) : isProcessing ? (
          <Loader2 size={20} className="animate-spin text-psi-gold" />
        ) : (
          <Mic size={20} className="group-hover:scale-110 transition-transform" />
        )}
        
        {isRecording && (
          <div className="absolute inset-0 rounded-2xl border-2 border-rose-400 animate-ping opacity-20" />
        )}
      </button>
      <span className="text-[8px] font-black uppercase tracking-widest text-slate-600">
        {isRecording ? 'Listening...' : 'Voice Note'}
      </span>
      {error && <span className="text-[7px] font-bold text-rose-500 uppercase">{error}</span>}
    </div>
  );
};