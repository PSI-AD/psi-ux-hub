import React, { useRef, useState, useMemo } from 'react';
import { 
  Camera, Search, Globe, Upload, ShieldCheck, Target, Sparkles, RefreshCw, 
  Eye, X, ListTodo, Zap, Palette, Layout, 
  Plus, Trash2, BarChart3, Users, FileText, Briefcase, UserCheck, CheckCircle2, ShieldAlert, BookmarkCheck
} from 'lucide-react';
import { PSIProject } from '../../types/index';
import { generateReport } from '../../services/reportService';
import { ReportPreview } from '../Report/ReportPreview';
import { extractBrandDNA } from '../../services/geminiService';
import { checkProjectReadiness } from '../../services/projectService';

interface ProjectSettingsProps {
  project: PSIProject;
  onUpdate: (updates: Partial<PSIProject>) => void;
  onLogoUpload: (base64: string) => void;
  onRunScan: () => void;
  onRunBrandAudit: () => void;
  toggleChecklistItem?: (itemId: string) => void;
  isProcessing: boolean;
}

type SettingsTab = 'brand' | 'market' | 'analytics' | 'standards' | 'architecture' | 'status';

const safeString = (val: any): string => {
  if (val === null || val === undefined) return '';
  if (typeof val === 'object') return JSON.stringify(val);
  return String(val);
};

export const ProjectSettings: React.FC<ProjectSettingsProps> = ({ 
  project, 
  onUpdate, 
  onLogoUpload, 
  onRunScan, 
  onRunBrandAudit, 
  toggleChecklistItem,
  isProcessing 
}) => {
  const logoInputRef = useRef<HTMLInputElement>(null);
  const guidelinesInputRef = useRef<HTMLInputElement>(null);
  const [showReportPreview, setShowReportPreview] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [isExtractingDNA, setIsExtractingDNA] = useState(false);
  const [isScanningCompetitors, setIsScanningCompetitors] = useState(false);
  const [activeTab, setActiveTab] = useState<SettingsTab>('brand');

  const readiness = useMemo(() => checkProjectReadiness(project), [project]);

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => onLogoUpload(ev.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleExtractDNA = async () => {
    if (!project.brand?.logo) return;
    setIsExtractingDNA(true);
    try {
      const dna = await extractBrandDNA(project.brand.logo, project.baseUrl);
      onUpdate({ brand: { ...project.brand, dna } });
    } catch (err) {
      console.error("DNA Extraction failed", err);
    } finally {
      setIsExtractingDNA(false);
    }
  };

  const handleScanCompetitors = async () => {
    setIsScanningCompetitors(true);
    setTimeout(() => setIsScanningCompetitors(false), 3000);
  };

  const handleExportReport = async () => {
    setIsExporting(true);
    try {
      await generateReport('luxury-report-container', safeString(project.name || 'PSI-Project'));
    } catch (err) {
      console.error("Report export failed", err);
    } finally {
      setIsExporting(false);
    }
  };

  const updateList = (field: 'competitors' | 'inspirationUrls', index: number, value: string) => {
    const newList = [...(project[field] || [])];
    newList[index] = value;
    onUpdate({ [field]: newList });
  };

  const addToList = (field: 'competitors' | 'inspirationUrls') => {
    onUpdate({ [field]: [...(project[field] || []), ''] });
  };

  const removeFromList = (field: 'competitors' | 'inspirationUrls', index: number) => {
    const newList = [...(project[field] || [])];
    newList.splice(index, 1);
    onUpdate({ [field]: newList });
  };

  const progress = useMemo(() => {
    if (!project.checklist || project.checklist.length === 0) return 0;
    const completed = project.checklist.filter(item => item.completed).length;
    return Math.round((completed / project.checklist.length) * 100);
  }, [project.checklist]);

  const TabButton = ({ id, icon: Icon, label }: { id: SettingsTab, icon: any, label: string }) => (
    <button 
      onClick={() => setActiveTab(id)} 
      className={`flex items-center gap-2 pb-4 text-[10px] font-black uppercase tracking-widest border-b-2 transition-all ${
        activeTab === id ? 'text-psi-gold border-psi-gold' : 'text-slate-500 border-transparent hover:text-white'
      }`}
    >
      <Icon size={14} />
      {safeString(label)}
    </button>
  );

  return (
    <div className="flex-1 overflow-y-auto custom-scrollbar p-12 bg-obsidian animate-in fade-in duration-500">
      <div className="max-w-6xl mx-auto space-y-12 pb-32">
        
        {/* Header Unit */}
        <header className="flex flex-col gap-8 border-b border-white/10 pb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <div 
                className="w-24 h-24 rounded-[2rem] bg-psi-gold/10 flex items-center justify-center border border-psi-gold/30 shadow-xl overflow-hidden cursor-pointer group hover:border-psi-gold transition-all"
                onClick={() => logoInputRef.current?.click()}
              >
                {project.brand?.logo ? (
                  <img src={project.brand.logo} className="w-full h-full object-contain" alt="Logo" />
                ) : (
                  <ShieldCheck className="text-psi-gold" size={40} />
                )}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                  <Camera size={24} className="text-white" />
                </div>
              </div>
              <input type="file" ref={logoInputRef} className="hidden" accept="image/*" onChange={handleLogoChange} />
              <div>
                <h2 className="text-4xl font-black text-white tracking-tighter uppercase">{safeString(project.name || "UNNAMED PROJECT")}</h2>
                <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.6em] mt-1">Sovereign Command Center</p>
              </div>
            </div>
            
            <div className="flex gap-4">
              {!readiness.isReady && (
                <div className="flex flex-col items-end justify-center mr-4">
                   <p className="text-[8px] font-black text-rose-500 uppercase tracking-widest mb-1">Intelligence Gap Detected</p>
                   <p className="text-[10px] font-bold text-slate-500 uppercase">{safeString((readiness.missing || []).length)} Prerequisites Pending</p>
                </div>
              )}
              <button 
                onClick={handleExtractDNA}
                disabled={isExtractingDNA || !project.brand?.logo}
                className={`flex items-center gap-3 px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg hover:scale-105 transition-all disabled:opacity-50 ${project.brand?.dna ? 'bg-white/5 text-psi-gold border border-psi-gold/30' : 'bg-psi-gold text-obsidian'}`}
              >
                {isExtractingDNA ? <RefreshCw className="animate-spin" size={14} /> : <Zap size={14} />} 
                {project.brand?.dna ? 'DNA Synchronized' : 'Sync Brand DNA'}
              </button>
            </div>
          </div>

          <div className="flex items-center gap-8 border-b border-white/5">
            <TabButton id="brand" icon={Palette} label="Brand DNA" />
            <TabButton id="market" icon={Target} label="Market Intel" />
            <TabButton id="analytics" icon={BarChart3} label="Persona & KPIs" />
            <TabButton id="standards" icon={BookmarkCheck} label="Industry Standards" />
            <TabButton id="architecture" icon={Layout} label="Architecture" />
            <TabButton id="status" icon={ListTodo} label="Status" />
          </div>
        </header>

        <main className="min-h-[500px]">
          {/* TAB: BRAND DNA */}
          {activeTab === 'brand' && (
            <div className="space-y-12 animate-in slide-in-from-right duration-500">
               <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                  <div className="space-y-10">
                     <div className="space-y-4">
                        <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-2">
                           <FileText size={14} className="text-psi-gold" /> Project Mission Statement
                        </label>
                        <textarea 
                           value={safeString(project.brand?.mission || "")}
                           onChange={(e) => onUpdate({ brand: { ...project.brand, mission: e.target.value } })}
                           className="w-full bg-white/5 border border-white/10 rounded-2xl p-6 text-sm text-slate-300 min-h-[140px] focus:border-psi-gold/50 outline-none transition-all placeholder:text-slate-700"
                           placeholder="Define the soul of the project..."
                        />
                     </div>
                     <div className="space-y-4">
                        <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-2">
                           <Eye size={14} className="text-psi-gold" /> Architectural Vision
                        </label>
                        <textarea 
                           value={safeString(project.brand?.vision || "")}
                           onChange={(e) => onUpdate({ brand: { ...project.brand, vision: e.target.value } })}
                           className="w-full bg-white/5 border border-white/10 rounded-2xl p-6 text-sm text-slate-300 min-h-[140px] focus:border-psi-gold/50 outline-none transition-all placeholder:text-slate-700"
                           placeholder="Where is the development going?"
                        />
                     </div>
                  </div>

                  <div className="space-y-10">
                     <div className="glass-card p-10 space-y-8 rounded-[2.5rem]">
                        <h4 className="text-[11px] font-black uppercase tracking-widest text-psi-gold flex items-center gap-2">
                          <ShieldCheck size={16} /> Asset Sovereignty
                        </h4>
                        <div 
                          className="border-2 border-dashed border-white/10 rounded-3xl p-16 text-center hover:border-psi-gold/30 transition-all cursor-pointer group"
                          onClick={() => guidelinesInputRef.current?.click()}
                        >
                           <Upload size={48} className="mx-auto text-slate-700 mb-6 group-hover:text-psi-gold transition-colors" />
                           <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Upload Brand Identity Kit (PDF)</p>
                           <input type="file" ref={guidelinesInputRef} className="hidden" accept=".pdf" />
                        </div>
                        
                        {project.brand?.dna ? (
                          <div className="space-y-6 pt-4">
                             <div className="h-px bg-white/5" />
                             <h5 className="text-[9px] font-black uppercase text-slate-500 tracking-widest">Extracted Design Tokens</h5>
                             <div className="grid grid-cols-2 gap-4">
                                <div className="p-4 bg-obsidian rounded-xl border border-white/5">
                                   <p className="text-[7px] font-bold text-slate-600 uppercase mb-1">Theme</p>
                                   <p className="text-[10px] text-psi-gold font-bold italic truncate">{safeString(project.brand.dna?.typography?.tone || "Standard Luxury")}</p>
                                </div>
                                <div className="p-4 bg-obsidian rounded-xl border border-white/5">
                                   <p className="text-[7px] font-bold text-slate-600 uppercase mb-1">Primary Color</p>
                                   <p className="text-[10px] text-white font-bold truncate">{safeString(project.brand.dna?.colors?.primary || "#FFFFFF")}</p>
                                </div>
                             </div>
                          </div>
                        ) : (
                          <p className="text-[9px] text-slate-600 uppercase italic text-center">Sync Logo DNA to extract high-fidelity tokens.</p>
                        )}
                     </div>
                  </div>
               </div>
            </div>
          )}

          {/* TAB: MARKET INTEL */}
          {activeTab === 'market' && (
            <div className="space-y-12 animate-in slide-in-from-right duration-500">
               <div className="flex justify-between items-center bg-psi-gold/5 border border-psi-gold/20 p-8 rounded-3xl">
                  <div className="flex gap-4 items-center">
                    <div className="w-12 h-12 bg-psi-gold/10 rounded-2xl flex items-center justify-center text-psi-gold">
                      <Target size={24} />
                    </div>
                    <div>
                      <h4 className="text-sm font-black uppercase tracking-widest text-white">Adversary Intelligence Mapping</h4>
                      <p className="text-[9px] text-slate-500 uppercase font-bold">Grouped competitor URLs for batch benchmarking.</p>
                    </div>
                  </div>
                  <button 
                    onClick={handleScanCompetitors}
                    disabled={isScanningCompetitors || (project.competitors || []).length < 1}
                    className="px-8 py-3 bg-psi-gold text-obsidian rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl hover:scale-105 transition-all disabled:opacity-50"
                  >
                    {isScanningCompetitors ? <RefreshCw className="animate-spin" size={14} /> : <Search size={14} />} 
                    Batch Scan All Competitors
                  </button>
               </div>

               <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                  <div className="space-y-8">
                     <div className="flex justify-between items-center border-b border-white/5 pb-4">
                        <h4 className="text-[11px] font-black uppercase tracking-widest text-white">Direct Competitors (URLs)</h4>
                        <button onClick={() => addToList('competitors')} className="p-2 bg-psi-gold text-obsidian rounded-lg hover:scale-110 shadow-lg"><Plus size={16} /></button>
                     </div>
                     <div className="space-y-4">
                        {(project.competitors || []).map((url, idx) => (
                           <div key={idx} className="flex gap-3">
                              <input 
                                 type="text" 
                                 value={safeString(url || "")} 
                                 onChange={(e) => updateList('competitors', idx, e.target.value)}
                                 className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-xs text-slate-300 focus:border-psi-gold/50 outline-none transition-all"
                                 placeholder="https://competitor-domain.com"
                              />
                              <button onClick={() => removeFromList('competitors', idx)} className="p-3 text-rose-500/30 hover:text-rose-500 transition-all"><Trash2 size={18}/></button>
                           </div>
                        ))}
                        {(project.competitors || []).length === 0 && (
                          <p className="text-[9px] text-slate-600 uppercase italic py-4 text-center border border-dashed border-white/10 rounded-xl">No competitors mapped.</p>
                        )}
                     </div>
                  </div>

                  <div className="space-y-8">
                     <div className="flex justify-between items-center border-b border-white/5 pb-4">
                        <h4 className="text-[11px] font-black uppercase tracking-widest text-white">Reference Aspiration URLs</h4>
                        <button onClick={() => addToList('inspirationUrls')} className="p-2 bg-white/5 text-psi-gold border border-psi-gold/20 rounded-lg hover:scale-110"><Plus size={16} /></button>
                     </div>
                     <div className="space-y-4">
                        {(project.inspirationUrls || []).map((url, idx) => (
                           <div key={idx} className="flex gap-3">
                              <input 
                                 type="text" 
                                 value={safeString(url || "")} 
                                 onChange={(e) => updateList('inspirationUrls', idx, e.target.value)}
                                 className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-xs text-slate-300 focus:border-psi-gold/50 outline-none transition-all"
                                 placeholder="https://luxury-inspiration.com"
                              />
                              <button onClick={() => removeFromList('inspirationUrls', idx)} className="p-3 text-rose-500/30 hover:text-rose-500 transition-all"><Trash2 size={18}/></button>
                           </div>
                        ))}
                        {(project.inspirationUrls || []).length === 0 && (
                          <p className="text-[9px] text-slate-600 uppercase italic py-4 text-center border border-dashed border-white/10 rounded-xl">No inspiration references added.</p>
                        )}
                     </div>
                  </div>
               </div>
            </div>
          )}

          {/* TAB: ANALYTICS & KPIs */}
          {activeTab === 'analytics' && (
            <div className="space-y-12 animate-in slide-in-from-right duration-500">
               <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                  <div className="glass-card p-12 space-y-10 rounded-[3rem]">
                     <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-500">
                          <UserCheck size={28} />
                        </div>
                        <h4 className="text-2xl font-black uppercase tracking-tighter text-white">Persona Builder</h4>
                     </div>
                     <div className="space-y-4">
                        <p className="text-[10px] text-slate-500 uppercase tracking-widest">Target Demographic Profiles</p>
                        <textarea 
                           value={safeString(project.businessObjectives?.targetAudience || "")}
                           onChange={(e) => onUpdate({ businessObjectives: { ...project.businessObjectives, targetAudience: e.target.value } })}
                           className="w-full bg-obsidian border border-white/10 rounded-[2rem] p-8 text-sm text-slate-400 min-h-[220px] outline-none focus:border-psi-gold/30 transition-all"
                           placeholder="• HNWIs in Abu Dhabi/Dubai
• International off-plan investors
• First-time luxury buyers..."
                        />
                     </div>
                  </div>
                  <div className="glass-card p-12 space-y-10 rounded-[3rem]">
                     <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-psi-gold/10 rounded-2xl flex items-center justify-center text-psi-gold">
                          <BarChart3 size={28} />
                        </div>
                        <h4 className="text-2xl font-black uppercase tracking-tighter text-white">Strategic KPIs</h4>
                     </div>
                     <div className="space-y-4">
                        <p className="text-[10px] text-slate-500 uppercase tracking-widest">Business Success Thresholds</p>
                        <textarea 
                           value={safeString(project.businessObjectives?.primaryKPIs || "")}
                           onChange={(e) => onUpdate({ businessObjectives: { ...project.businessObjectives, primaryKPIs: e.target.value } })}
                           className="w-full bg-obsidian border border-white/10 rounded-[2rem] p-8 text-sm text-slate-400 min-h-[220px] outline-none focus:border-psi-gold/30 transition-all"
                           placeholder="Identify the numerical targets for this audit..."
                        />
                     </div>
                  </div>
               </div>
            </div>
          )}

          {/* TAB: INDUSTRY STANDARDS */}
          {activeTab === 'standards' && (
            <div className="space-y-12 animate-in slide-in-from-right duration-500">
               <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-3xl font-black text-white uppercase tracking-tighter">Niche Intelligence: {safeString(project.industry || "General")}</h3>
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.4em] mt-2">Cross-referencing domain against Platinum Sector Benchmarks</p>
                  </div>
                  <div className="px-6 py-3 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-center gap-3">
                     <ShieldCheck size={20} className="text-emerald-500" />
                     <span className="text-[10px] font-black uppercase text-emerald-500 tracking-widest">AI Verification Active</span>
                  </div>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {(project.industryStandards || []).map((group, gIdx) => (
                    <div key={gIdx} className="space-y-6">
                       <h4 className="text-[11px] font-black uppercase tracking-[0.3em] text-psi-gold border-b border-psi-gold/20 pb-3">{safeString(group.name || "Untitled Group")}</h4>
                       <div className="space-y-4">
                          {(group.items || []).map((item) => (
                            <div key={safeString(item.id)} className="glass-card p-5 rounded-2xl group/item hover:border-psi-gold/30 transition-all">
                               <div className="flex justify-between items-start mb-3">
                                  <span className={`px-2 py-0.5 rounded-[4px] text-[7px] font-black uppercase tracking-tighter border ${
                                    item.type === 'must-have' ? 'bg-rose-500/10 text-rose-500 border-rose-500/20' : 
                                    item.type === 'recommended' ? 'bg-psi-gold/10 text-psi-gold border-psi-gold/20' : 
                                    'bg-blue-500/10 text-blue-500 border-blue-500/20'
                                  }`}>
                                    {safeString(item.type || "unknown")}
                                  </span>
                                  <div className="flex items-center gap-1.5">
                                     {item.status === 'checked-ai' ? (
                                       <div className="flex items-center gap-1.5 text-emerald-500">
                                          <CheckCircle2 size={12} />
                                          <span className="text-[8px] font-black uppercase tracking-widest">Detected</span>
                                       </div>
                                     ) : item.status === 'missing' ? (
                                       <div className="flex items-center gap-1.5 text-rose-500">
                                          <ShieldAlert size={12} />
                                          <span className="text-[8px] font-black uppercase tracking-widest">Missing</span>
                                       </div>
                                     ) : (
                                       <div className="flex items-center gap-1.5 text-slate-500">
                                          <RefreshCw size={12} />
                                          <span className="text-[8px] font-black uppercase tracking-widest">Verify</span>
                                       </div>
                                     )}
                                  </div>
                               </div>
                               <h5 className="text-[11px] font-bold text-white mb-1">{safeString(item.label || "Untitled Component")}</h5>
                               <p className="text-[9px] text-slate-500 leading-tight group-hover/item:text-slate-400 transition-colors">{safeString(item.description || "No description provided.")}</p>
                            </div>
                          ))}
                       </div>
                    </div>
                  ))}
               </div>

               <section className="glass-card p-10 border border-dashed border-white/10 rounded-[3rem] flex items-center justify-between">
                  <div className="flex gap-6 items-center">
                    <div className="w-14 h-14 rounded-full bg-obsidian flex items-center justify-center text-psi-gold border border-white/5 shadow-2xl">
                      <Zap size={24} />
                    </div>
                    <div>
                       <h4 className="text-lg font-black text-white uppercase tracking-tight">Compliance ROI Narrative</h4>
                       <p className="text-[10px] text-slate-500 uppercase tracking-widest">Filling niche gaps adds approximately <strong>+18%</strong> to predicted conversion rate.</p>
                    </div>
                  </div>
                  <button className="px-8 py-3 bg-white/5 border border-white/10 text-white rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-white/10 transition-all">Refine Niche Standard</button>
               </section>
            </div>
          )}

          {/* TAB: ARCHITECTURE */}
          {activeTab === 'architecture' && (
            <div className="space-y-10 animate-in slide-in-from-right duration-500">
               <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  <div className="space-y-4">
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-2"><Globe size={14}/> Domain Root</label>
                    <input 
                      type="text" 
                      value={safeString(project.baseUrl || "")} 
                      disabled
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-5 text-slate-500 font-mono text-sm cursor-not-allowed"
                    />
                  </div>
                  <div className="space-y-4">
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-2"><Briefcase size={14}/> Industry Sector</label>
                    <input 
                      type="text" 
                      value={safeString(project.industry || "")} 
                      onChange={(e) => onUpdate({ industry: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-5 text-white focus:border-psi-gold/50 outline-none transition-all"
                    />
                  </div>
               </div>
               
               <section className="glass-card p-12 text-center space-y-8 rounded-[3rem]">
                <div className="w-16 h-16 bg-psi-gold/10 rounded-2xl mx-auto flex items-center justify-center text-psi-gold">
                  <BarChart3 size={32} />
                </div>
                <div className="space-y-3">
                  <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Executive Transformation Summary</h3>
                  <p className="text-sm text-slate-500 max-w-md mx-auto leading-relaxed">Compile current intelligence into a high-fidelity client presentation.</p>
                </div>
                <div className="flex justify-center gap-4">
                  <button onClick={() => setShowReportPreview(true)} className="px-10 py-4 bg-white/5 border border-white/10 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-white/10 transition-all">Preview Mode</button>
                  <button onClick={handleExportReport} className="px-10 py-4 bg-psi-gold text-obsidian rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl hover:scale-105 transition-all">Generate Package</button>
                </div>
              </section>
            </div>
          )}

          {/* TAB: STATUS */}
          {activeTab === 'status' && (
            <div className="space-y-10 animate-in slide-in-from-right duration-500">
               <div className="flex items-center justify-between border-b border-white/10 pb-10">
                  <div>
                    <h4 className="text-3xl font-black text-white uppercase tracking-tighter">Project Integrity Status</h4>
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.4em] mt-2">Prerequisites for Phase 1 Architectural Analysis</p>
                  </div>
                  <div className="text-right">
                     <span className={`text-5xl font-black font-mono tracking-tighter ${readiness.isReady ? 'text-emerald-500' : 'text-psi-gold'}`}>
                        {readiness.isReady ? '100' : safeString(progress)}%
                     </span>
                     <p className="text-[9px] font-black text-slate-700 uppercase tracking-widest">Audit Stability Score</p>
                  </div>
               </div>
               
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {(project.checklist || []).map((item) => (
                    <div 
                      key={safeString(item.id || Math.random().toString())} 
                      onClick={() => toggleChecklistItem?.(item.id)}
                      className={`p-8 rounded-[2rem] border cursor-pointer transition-all flex flex-col gap-6 group ${
                        item.completed ? 'bg-emerald-500/5 border-emerald-500/20' : 'bg-white/5 border-white/10 hover:border-psi-gold/40'
                      }`}
                    >
                       <div className="flex items-center justify-between">
                          <span className="text-[8px] font-black uppercase text-slate-600 tracking-[0.3em]">{safeString(item.category || "General")}</span>
                          <div className={`w-8 h-8 rounded-xl border-2 flex items-center justify-center transition-all ${
                            item.completed ? 'bg-emerald-500 border-emerald-500 text-obsidian shadow-[0_0_15px_rgba(16,185,129,0.3)]' : 'border-white/10'
                          }`}>
                             {item.completed && <Zap size={16} className="fill-obsidian" />}
                          </div>
                       </div>
                       <p className={`text-sm font-bold leading-tight ${item.completed ? 'text-emerald-400/80' : 'text-slate-300'}`}>{safeString(item.label || "Untitled Task")}</p>
                    </div>
                  ))}
               </div>
            </div>
          )}
        </main>
      </div>

      {showReportPreview && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-12 bg-black/98 backdrop-blur-2xl">
           <div className="w-full max-w-7xl h-full overflow-y-auto custom-scrollbar bg-obsidian rounded-[4rem] border border-white/10 relative shadow-[0_50px_100px_rgba(0,0,0,1)]">
             <ReportPreview project={project} />
             <button onClick={() => setShowReportPreview(false)} className="fixed top-16 right-16 p-5 bg-white/5 hover:bg-white/10 text-white rounded-full transition-all border border-white/10 z-[1001]"><X size={32}/></button>
           </div>
        </div>
      )}
    </div>
  );
};